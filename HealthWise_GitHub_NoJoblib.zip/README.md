# HealthWise Smart Premium Engine

Deployment-ready Streamlit dashboard. This version intentionally uses **no joblib file**. The classification model and the three tier-specific regression models are trained from `healthwise.csv` when the app starts and cached by Streamlit.

## Required repository layout

```text
app.py
healthwise.csv
requirements.txt
runtime.txt
.streamlit/config.toml
```

## Streamlit Community Cloud
1. Upload the files above to the root of a GitHub repository.
2. Do not rename `app.py` to `app (3).py`.
3. In Streamlit Community Cloud choose the repository and set **Main file path** to `app.py`.
4. Deploy. If an older deployment is cached, reboot the app after pushing these files.

## Local run
```bash
pip install -r requirements.txt
streamlit run app.py
```
